from collections import defaultdict
import json

#sem_sc_data={'1234':['On the Douglas-Rachford splitting method and the proximal point algorithm for maximal monotone operators','This paper shows, by means of a new type of operator called a splitting operator, that the Douglas-Rachford splitting method for finding a zero of the sum of two monotone operators is a special case of the proximal point algorithm. Therefore, applications of Douglas-Rachford splitting, such as the alternating direction method of multipliers for convex programming decomposition, are also special cases of the proximal point algorithm. The approach taken here also essentially subsumes the theory of partial inverses developed by Spingarn. We show the usefulness of the connection between Douglas-Rachford splitting and the proximal point algorithm by deriving a new, generalized alternating direction method of multipliers for convex programming. Running Heads: Operator Splitting and the Proximal Point Algorithm'],'12345':['Conic Optimization via operator Splitting and Homogeneous Self-Dual Embedding', 'We introduce a first-order method for solving very large convex cone programs. Themethod uses an operator splittingmethod, the alternating directionsmethod of multipliers, to solve the homogeneous self-dual embedding, an equivalent feasibility problem involving finding a nonzero point in the intersection of a subspace and a cone. This approach has several favorable properties. Compared to interior-point methods, first-order methods scale to very large problems, at the cost of requiring more time to reach very high accuracy. Compared to other first-order methods for cone programs, our approach finds both primal and dual solutions when available or a certificate of infeasibility or unboundedness otherwise, is parameter free, and the per-iteration cost of the method is the same as applying a splitting method to the primal or dual alone. We discuss efficient implementation of the method in detail, including direct and indirect methods for computing projection onto the subspace, scaling the original problem data, and stopping criteria. We describe an open-source implementation, which handles the usual (symmetric) nonnegative, second-order, and semidefinite cones as well as the (non-self-dual) exponential and power cones and their duals. We report numerical results that show speedups over interior-point cone solvers for large problems, and scaling to very large general cone programs.']}
with open('sm_output.json') as data_file:    
    sem_sc_data = json.load(data_file)

for k in sem_sc_data:
    print(k["title"])
   
##    for k1 in k:
##          print(k1)
##          print(",,,,,,,,,,,,,,,")

    
##Index=defaultdict(list)
##Index1=defaultdict(list)
##f = open("list_of_queries.txt","r") 
##for line in f:
##    query_terms = line.split(" ")
##    for key in query_terms:
##        if(len(key)>2):
##            Index[key]=''
##            #print(key)
##
##for keyQ in Index:
##     for keyD in sem_sc_data:
##          doc_zone_t=0
##          doc_zone_b=0
##          term_freq=0
##          title_terms=sem_sc_data[keyD][0].split()
##          for terms_t in title_terms:
##              if keyQ.lower() in terms_t.lower(): 
##                   term_freq=term_freq+1
##                   doc_zone_t=1
##          abstract_terms=sem_sc_data[keyD][1].split()
##          for terms_t in abstract_terms:
##              if keyQ.lower() in terms_t.lower(): 
##                   term_freq=term_freq+1
##                   doc_zone_b=2
##          doc_zone=doc_zone_b+doc_zone_t
##          if doc_zone>0:
##               Index1[keyQ].append({keyD:[doc_zone,term_freq]})
##print(Index1)
##
##with open('file.txt', 'w') as file:
##     file.write(json.dumps(Index1))
##
##          
